# Forge Binding Results v0.26 — WRL Phase 3D (CompilePlanV1 convergence + Fixture retirement) + WRL Phase 3C (canvas↔text↔runtime isomorphism) + 3C-0 sealing preflight + WRL slice 2.1 (sealing + lexical errata) + WRL slice 2 (Canonical Identity spine) + WRL slice 1 (WRL Core → Forge Semantic IR v1 → Fixture → TRVM → Film v0.7) + 3b.5f-2b BUILD/MEASURE + 3b.5f-2a BUILD/MEASURE + 3b.5f-1 (golden ADMIT + Film v0.7 + two golden repairs)

**WRL PHASE 3D PASS_REF_AND_NATIVE (31s, 15 checks D1–D15) — `wrl_plan.py` (new) + `wrl_ir.py` + `wrl_canvas.py` + `binding_run6.py` + `binding_run7.py` (new).**
GPT-5.6 ordered a deterministic **CompilePlanV1** extracted between the frozen
Forge IR and the existing backend, so both the sealed IR and the legacy Fixture
converge on ONE plan; then remove Fixture construction from `lower_graph`,
keeping the Fixture only as an independent test oracle. **(3D-0)** semantic
strictness first: `validate_canvas_v1` rejects unknown canvas/node/connection
SEMANTIC keys (presentation stays open + inert) and `_coerce_cfg` rejects
unknown `static_config` fields per role (`_CFG_KEYS`) — both typed
`WRL_UNSUPPORTED_FEATURE`. **(3D-1)** `wrl_plan.py` adds **CompilePlanV1** — a
validated, JSON-plain, backend-neutral preparation (18 GPT-5.6 fields +
`compile_plan_version`); it carries NO Scott encoding, DUP labels, generated
variable names, tuple nesting, one-hot/binary counter representation, native
offsets, or CUDA layouts. `_PlanView` duck-types the small structural read
interface the compiler already consumes (layout/orbs/pulsers/spinners/
counter_spec/wires/controller_of/orb_of/is_configurable/kinds/wire_role), so
`compile_plan_to_ic(plan) = compile_step_v6(_PlanView(plan))` reuses the
existing compiler UNCHANGED — no parallel compiler. A single builder
`_plan_from_parts` (sorted/canonical throughout) is called by BOTH
`artifact_to_compile_plan_v1` and `fixture_to_compile_plan_v1`, so the two
entry points emit byte-identical plans. **(3D-2)** `compile_artifact` /
`compile_program` return a `CompiledProgram` (plan, ic_term, fields,
BackendArtifactID); the representation threshold (`ONEHOT_MAX`) stays inside the
shim, not the plan. **(3D-3)** `lower_graph` no longer builds a Fixture:
`LoweredProgram` now carries `sealed_artifact / semantic_artifact_id /
initial_claim_state / run_plan / epoch_inputs / canonical_graph`; the Fixture is
reachable only via the lazy `as_fixture_for_test()` (imports `Fixture` inside the
function). D1 plan(IR)==plan(Fixture) byte-identical over 6 structural worlds;
D2 reorder-equivalent artifact → identical plan; D3 JSON round-trip → identical
digest; D4 bootstrap/text/canvas → identical plan; D5 plan-view init state ==
Fixture init state; **D6/D8** native-gated plan-fed epoch trajectory + step ==
**ic_ref == ic32 == golden**; D7 plan-view Film v0.7 == Fixture Film every epoch;
D9 plan-fed and Fixture-fed compiled steps are the SAME function over randomized
reachable states (native on core); D10 unknown canvas key AND unknown
static_config field are typed rejects; D11 presentation-only edit moves NEITHER
plan digest NOR BackendArtifactID; D12 semantic edit moves BOTH; D13
lowering-profile change preserves SemanticArtifactID, moves BackendArtifactID;
D14 a subprocess probe proves production lowering imports NO Fixture and NO
compiler; D15 the retained Fixture oracle still folds to the golden trajectory
(native). Regressions clean: `binding_run3o` (golden fold), `binding_run4`
(slice 1), `binding_run5` (slice 2.1), `binding_run6` (3C) all
PASS_REF_AND_NATIVE. `admit.py` / `compiler.py` / `fixture.py` untouched; no new
runtime constructs. **Fixture is retired as the production lowering contract
(CompilePlanV1 replaces it) and retained as an independent test-builder/oracle —
NOT deleted.** Next per ruling: 3B ergonomic surface widening, then the first
visible Forge demo.

# Forge Binding Results v0.25 — WRL Phase 3C (canvas↔text↔runtime isomorphism) + 3C-0 sealing preflight + WRL slice 2.1 (sealing + lexical errata) + WRL slice 2 (Canonical Identity spine) + WRL slice 1 (WRL Core → Forge Semantic IR v1 → Fixture → TRVM → Film v0.7) + 3b.5f-2b BUILD/MEASURE + 3b.5f-2a BUILD/MEASURE + 3b.5f-1 (golden ADMIT + Film v0.7 + two golden repairs)

**WRL PHASE 3C PASS_REF_AND_NATIVE (8s, 12 checks V1–V12) — `wrl_canvas.py` + `binding_run6.py`; 3C-0 preflight folded into `binding_run5.py` (now 20 checks C1–C20).**
GPT-5.6 approved Phase 3C with a mandatory identity preflight. **(3C-0)** canonical
artifact SEALING is now the identity path: `canonicalize_artifact_v1` normalizes a
valid-shaped artifact (objects by `(object_id, role)`, edges by `(kind, src, dst)`,
`numeric_policy_ids` and each port array sorted; rotor lanes/clock stay POSITIONAL),
and `_seal` = validate → canonicalize → re-validate → serialize. `SealedArtifact`
carries a fresh ISOLATED canonical copy, so caller mutation after sealing cannot
change an issued identity; `semantic_artifact_id` routes through `_seal`. The
backend identity domain is strict: `validate_semantic_id` requires `sem-<64 lowercase
hex>` and `validate_lowering_profile_v1` requires `encoding ∈ {one_hot, binary}` +
the pinned `lowering_profile_version`, else `WRL_BAD_LOWERING_PROFILE`. New **C19**
reorder-equivalent artifacts (reversed objects/edges, reordered policy ids, JSON
round-trip) seal to identical bytes + SemanticArtifactID and the sealed value is
isolated from caller mutation; **C20** malformed/short/uppercase-hex sem ids, unknown
encodings, and unsupported profile versions are all `WRL_BAD_LOWERING_PROFILE`.
**(3C-1)** `wrl_canvas.py` adds CanvasGraphV1 — presentation metadata AROUND, not
inside, the canonical WRL graph. Each node/connection keeps SEMANTIC fields at top
level (object_id/role/static_config; kind/src/dst) and a separate `presentation`
block (x/y/width/height/color/label_style/collapsed/layer; control_points/
line_length/texture_style/paint/label_position). Ports are NOT stored — they derive
from the frozen role registry. `graph_to_canvas` / `canvas_to_graph` /
`graph_to_wrl_core` / `lower_canvas` convert; `canvas_to_graph` reads ONLY semantic
keys, so presentation is structurally unreachable from the lowering path. All three
surfaces share the new `wrl_ir.lower_graph` seam. **(3C-2/3/4)** `binding_run6.py`
proves V1 text→graph→canvas→graph retains the id (bytes + batches); V2
canvas→graph→WRL text→graph retains it; V3 move / V4 line geometry / V5 recolor do
NOT change it; V6 rotor / V7 reconnect DO; V8 duplicate Orb controller in the canvas
→ `WRL_CONTROLLER_CONFLICT`; V9 canvas derives / text checks the SAME frozen port
signature and a corrupted/deleted presentation cannot override the identity; V10
bootstrap / WRL text / canvas lower to IDENTICAL bytes; V11 every presented node is
anchored to a real object id; V12 native-gated **ic_ref == ic32 == golden** over the
whole trajectory lowered FROM A CANVAS. Regressions clean: slice-2.1 (`binding_run5`,
now C1–C20) and slice-1 (`binding_run4`) PASS_REF_AND_NATIVE; golden `binding_run3o`
unaffected (`admit.py` untouched). No new runtime constructs; the Fixture adapter is
kept through 3C. Next per ruling: 3D direct IR→backend (retire the adapter), then 3B
ergonomic surface widening.

**WRL SLICE 2.1 PASS_REF_AND_NATIVE (6s, 18 checks C1–C18) — `wrl_canonical.py` + `wrl_ir.py` + `binding_run5.py`.**
GPT-5.6 accepted Slice 2 provisionally and ordered a sealing/lexical errata
before Phase 3C. Closed three identity holes plus three tightenings. **(E1)**
`rulepack_id` is no longer `None` — it names the transition law
`forge.world.core.rules.v1`; new `seal_artifact` → `SealedArtifact` and
`validate_artifact_v1` reject null/empty policy ids (`WRL_UNSEALED_POLICY`),
unknown schema blocks, unsupported ir/profile versions, and malformed
object/edge records; `semantic_artifact_id` now VALIDATES before hashing, so an
unsealed policy can never earn an identity. **(E2)** a WRL `{ports}` brace group
is a CHECKED projection of the role's frozen ports — `validate_port_projection`
rejects `{bogus}`/`{}` with `WRL_PORT_SIGNATURE`; visible source is never
silently ignored, and the honest projection lowers identically to the
registry-derived ports. **(E3)** `parse_wrl_core` obeys WRL's lexical law: `;`
comments (full-line + inline) and `#` is preserved for content identity/tags
(never a comment marker); the bootstrap DSL keeps `#` comments for now. **(E4)**
objects are canonicalized IDENTITY-FIRST by `(object_id, role)` — stable if the
role registry expands. **(E5)** `validate_lowering_profile_v1` requires
encoding/numeric_backend/compiler_hash/target/lowering_profile_version, so a
half-specified backend cannot earn a `BackendArtifactID`
(`WRL_BAD_LOWERING_PROFILE`); `backend_artifact_id` validates before hashing.
**(E6)** `LoweredProgram.initial_state` → `initial_claim_state`: a partial claim
projection is no longer misnamed the full initial runtime state. New checks
**C13** unsealed rulepack → `WRL_UNSEALED_POLICY`; **C14** a different
`rulepack_id` moves the SemanticArtifactID; **C15** bogus/empty `{ports}` →
`WRL_PORT_SIGNATURE`, honest projection lowers identically; **C16** `;` comments
obeyed and `#` preserved; **C17** half-specified lowering profile →
`WRL_BAD_LOWERING_PROFILE`; **C18** objects in identity-first order. C1–C12
unchanged and still green (C12 native-gated **ic_ref == ic32 == golden**).
slice-1 (`binding_run4`) and golden `binding_run3o` regressions stay
PASS_REF_AND_NATIVE. No new runtime constructs. Next per ruling: Phase 3C
canvas↔text isomorphism (keep the Fixture adapter through it).

**WRL SLICE 2 PASS_REF_AND_NATIVE (8s, 12 checks C1–C12) — `wrl_canonical.py` + `binding_run5.py`.**
GPT-5.6 Ruling B: freeze the identity spine before widening WRL features.
Delivered the five ruled fixes and proved them: **(F1)** the STATIC semantic
artifact is separated from run inputs — `lower_program` returns a
`LoweredProgram{artifact, initial_state, run_plan, epoch_inputs, fixture,
graph}`; `graph_to_ir` no longer emits `periods`/`batches` (D3). **(F2)**
`wrl_canonical.py` is the single source of the frozen registries plus
`validate_graph` / `canonicalize_graph` / `serialize_artifact` (deterministic
sorted-key bytes) / `semantic_artifact_id` (`sem-…`) / `backend_artifact_id`
(`bknd-…`); the SemanticArtifactID is a pure function of the frozen semantic
graph (objects+static_config, structural edges, semantic policy ids) and the
BackendArtifactID folds in the lowering profile (encoding, numeric backend,
compiler hash, target). **(F3)** two surfaces — `parse_wrl_bootstrap` (the
line DSL) and `parse_wrl_core` (WRL process notation
`[pulser:p0](mode=periodic, period=2, phase=0){sig_out}` /
`[p0] --sig--> [sp]`) — lower to IDENTICAL canonical bytes and run inputs.
**(F4)** typed structural validation with stable codes
(`WRL_DUPLICATE_ID`, `WRL_UNKNOWN_ENDPOINT`, `WRL_ILLEGAL_PORT_PAIR`,
`WRL_CONTROLLER_CONFLICT`, `WRL_CLOCK_RANGE`, `WRL_NUMERIC_RANGE`,
`WRL_EPOCH_RANGE`, `WRL_UNSUPPORTED_FEATURE`) — the IR validator owns them, not
the Fixture ctor (`WrlValidationError(WrlUnsupported)` keeps `except
WrlUnsupported` working). **(F5)** the rejected-claim Film v0.7 projection gap
is closed: an out-of-fixture target name is non-authoritative diagnostic
metadata, so `film_bytes_v7` renders it as the canonical sentinel `#?` on BOTH
the golden side (literal `zz`) and the lossy projection (`?`) — full 3-epoch
film parity now holds. Checks: **C1** two declaration orders → identical
SemanticArtifactID; **C2** bootstrap == process-notation (bytes + run inputs);
**C3** claim batches do NOT affect the SemanticArtifactID; **C4** a different
initial rotor DOES; **C5** a different numeric policy DOES; **C6** one-hot vs
binary keeps the SemanticArtifactID, moves the BackendArtifactID; **C7** a
different compiler identity moves the BackendArtifactID; **C8/C9** duplicate id
and illegal port pair are typed rejections; **C10** ALL 3 epochs (incl. the
rejected invalid-target claim) have full Film v0.7 parity; **C11** the
canonical artifact round-trips through serialization; **C12** **ic_ref == ic32
== golden** over the whole WRL-lowered trajectory (native-gated). No new
runtime constructs were added — the spine is green. `admit.py` gained the
fixture-aware `_payload_str` sentinel; slice-1 (`binding_run4`) and the golden
`binding_run3o` regressions stay PASS_REF_AND_NATIVE.

**WRL SLICE 1 PASS_REF_AND_NATIVE (6s, 4 cases W1–W4) — `wrl_ir.py` + `binding_run4.py`.**
The first sanctioned WRL lowering, end to end on the grounded
deterministic-circuit-world (GPT-5.6 ruling: freeze Forge Semantic IR v1 as
profile `forge.world.core.v1`, then implement one vertical slice). Pipeline:
**WRL Core text → canonical WRL graph → ForgeSemanticArtifactV1 → current
Fixture adapter → TRVM `compile_step_v6` + ADMIT reducer → ic_ref/ic32 → Film
v0.7.** `wrl_ir.py`: a minimal restricted WRL surface parser (5 built-in roles
Pulser/Relay/Door/Spinner/Orb, 2 structural edges SignalWire/SocketControl,
fixed-point rotor decls, SetRotor/ResetFault, N periods), `graph_to_ir`
(frozen top-level form + role/edge-registry closure), `ir_to_fixture` (the
adapter; static artifact only — EpochInput threaded separately, D3), and
`WrlUnsupported` diagnostics for everything out of scope. Cases: **W1** WRL
text → IR v1 → Fixture reproduces hand-built `mkfx(8,4)` EXACTLY
(pulsers/doors/edges/spinners/orbs/sockets); **W2** emitted artifact carries
the frozen shape (profile, 5-role + 2-edge closure, `admit_candidate_min_firstreceipt_v1`
pinned, NO backend encoding — D4 semantic/backend split); **W3** the SAME WRL
program folds over K=3 epochs in ONE IC term whose single native normalization
renders the IDENTICAL Film v0.7 trajectory as golden `admit_step`+world-step
(**ic_ref == ic32 == golden**, reusing the 3b.5f-2b `binding_run3o` fold since
the adapter fixture == `binding_run3o.FX`; valid-target epochs 1–2 for film
parity per the run3n/run3o projection-limit discipline); **W4** async `~~`
route, capability `gate`, `seal`, a sixth role, and an out-of-registry edge
each raise a clear `WrlUnsupported` — NEVER a speculative lowering. Frozen
specs (TRVM-root, not the forge E2 bundle): `FORGE_SEMANTIC_IR_v1.md`
(profile `forge.world.core.v1`; node envelope + 5 roles; 2 edges; static policy
refs; top-level runtime ClaimState; separate EpochInput; semantic signatures
with Semantic/Backend artifact-ID split; v1.1 additive / v2 semantic) and
`WRL_CORE_0.1.md` rev **0.1.1** errata (cycle OBSERVE→ACCEPT→MAP→COMMIT→REACT→FILM;
narrowed conflicts-dissolve; policy-pinned canonical key; WorldFrame/EventLedger/BuildFilm;
corrected grounding table).

**SLICE 3b.5f-2b BUILD (FOLD) PASS_REF_AND_NATIVE (34s, 5 cases) —
`admit_ic.py` (`ic_reduce` made linear in `rv`) + `binding_run3o.py`.** The
single-epoch reducer (3b.5f-2a) is folded over K epochs into ONE
interaction-calculus term that threads BOTH the persistent ClaimState (fact
vector + receipt vector) AND the WorldState (v0.6 encoded physical state) across
epochs, gated by a SINGLE native normalization producing the WHOLE trajectory
(one `native()` call yields every epoch's world + claim state). Per epoch e:
`red_e = ic_reduce(fv_e, rv_e, batch_srcs[e])` → `world_{e+1} =
((compile_step_v6 EC) world_e)` — the reducer's emitted `EpochControl` is fed
DIRECTLY into `compile_step_v6` (3b.5f-2b MEASURE proved it equals golden
`enc_config_bundle`). Each epoch emits `(world', fv', rv', fobs, facc)`; the K
epochs are a flat `TUP(5·K)` in ONE term, decoded via `_spine(nf, 5·K)`.

**Two load-bearing IC facts pinned here.** (1) **Linearity fix:** `ic_reduce`
reads its receipt input in BOTH `ic_accept` and `ic_map`, so it now binds
`rv_in_src` once and `!&`-dups it — the reducer is linear in `rv` and thus
composable when `rv` is a bound variable from the previous epoch (a literal
still works; all 3b.5f-2a cases re-pass native). (2) **This IC grammar has NO
parenthesized-single-term rule:** `(X)` is ALWAYS an application `(f a)`; to
apply a lambda whose body is bounded, write `(λx.BODY arg)` NOT `((λx.BODY) arg)`
(the latter parses `(λx.BODY)` as an app with a missing operand).

Battery (all native-gated): **O1** three-epoch persistence (rotor → rotor+reset
→ invalid-NoChange; facts accumulate [1,3,4], receipts first-authoritative, the
physical world evolves and the pre-existing `fault_ob` is reset in epoch 2);
**O2** two-epoch canonical (epoch-1 later-canonical rotor `(16,0,99,0)` commits,
epoch-2 reset); **O3 arrival-order independence (O2 epoch-1 batch reversed →
IDENTICAL trajectory) — PERMANENT REGRESSION**; **O4** first-receipt
authoritative ACROSS epochs ((1,1) receipted in epoch 1 keeps its `0xf6` digest,
NOT remapped by a re-claim in epoch 2; fresh (2,2) reset applies); **O5 Film
v0.7 trajectory parity** — every epoch's fold projection renders the IDENTICAL
v0.7 film (physical + claim + receipt-with-epoch) as the golden `admit_step` +
world-step trajectory. **Receipt `accepted_epoch` is NOT carried in the IC
receipt vector** (a receipt is identified by its CandidateKey; epoch is
provenance) — the projection recovers it faithfully as the epoch of a receipt's
FIRST appearance in the trajectory, which is exactly the epoch `admit_step`
accepted it. **One honest projection limit:** a REJECTED SetRotor at an INVALID
target keeps only its packed CandidateKey (`kind|idx`) in the fact vector — the
original target NAME is not carried (idx has no spinner ⇒ renders `?`), so O5
asserts Film parity over VALID-target trajectories (same discipline as
`binding_run3n` R9); the fact/receipt/world TRAJECTORY is nonetheless exact and
O1 exercises the invalid→NoChange world case in full.

---

**SLICE 3b.5f-2b MEASURE (BRIDGE) PASS_REF_AND_NATIVE (4 cases) — `admit_ic.py`
+ `compiler.py` (`compile_step_v6`, `enc_config_bundle`).** Measure-before-
building for the world wiring: the reducer's emitted `EpochControl` (field 2 of
the `TUP5`, projected via `λa.λb.λc.λd.λe.c`), fed DIRECTLY into
`compile_step_v6`, drives the v0.6 world state IDENTICALLY to the golden
`enc_config_bundle` EC — `dec_state_v6` equal, ref == native — over
setrotor+reset, setrotor-only, reset-only, and invalid→NoChange (with a
pre-existing `fault_ob=1` reset). Confirms `ic_map`'s `rotor_cfg` matches
`enc_rotor_config` exactly and `_PAIR(rotor_bundle, fault_bundle)` ==
`enc_config_bundle` for `mkfx(8,4)`, so the reducer EC is directly consumable by
the step function. This licensed the 3b.5f-2b fold.

---

**SLICE 3b.5f-2a BUILD (REDUCER) PASS_REF_AND_NATIVE (11s, 9 cases) —
`admit_ic.py` (`ic_insert_sorted`, `ic_observe`, `ic_accept`, `ic_map`,
`ic_reduce`) + `binding_run3n.py`.** The single-epoch ADMIT reducer is now
composed as ONE interaction-calculus term and gated by a SINGLE native
normalization per case (`ic_ref == ic32 == golden`). `ic_reduce` threads
facts + receipts through all three phases —
`ic_observe` (atomic compare-shift insert + distinct-new count + capacity
gate + dedup) → `ic_accept` (per-event-group MIN via sorted order, first
receipt authoritative, atomic receipt gate) → `ic_map` (newly-accepted
Applied ops → `EpochControl = TUP(rotor_bundle, fault_bundle)`) — over
**Option A occupied-prefix sorted structural vectors** (empty slots = ALL-ONES
key, sinks to bottom, present DERIVED). The load-bearing composition insight:
**ACCEPT and MAP both read the PRE-accept receipt vector** (facts are monotone,
so the post-OBSERVE fact vector `fv'` feeds ACCEPT, MAP, and the output, dup'd
three ways; `rv_in` is pure data, inlined into both). Output is
`TUP5(fact_vec', receipt_vec', EpochControl, fact_capacity_fault,
receipt_capacity_fault)`.

Battery (all native-gated): R1 SetRotor+ResetFault → EC + facts + receipts;
R2 later-canonical-wins (canonically-later rotor committed); **R3 arrival-order
independence (R2 reversed → identical output) — PERMANENT REGRESSION**; R4
first-receipt authoritative (pre-receipted event not remapped, fresh event in
same batch still applies); R5 invalid target → Rejected → NoChange; **R6
collision 0xf6 (two payloads, one reduced digest, DISTINCT fkeys) → OBSERVE
keeps BOTH facts (disputed), ACCEPT/MAP pick the min-ckey group leader —
Correction 1 through the whole reducer**; R7 fact-capacity overflow (batch
that does not fit latches `fact_capacity_fault`, inserts NONE, NoChange);
**R8 fact-overflow reversed batch → identical reject verdict — PERMANENT
REGRESSION**; R9 **Film v0.7 parity** — the reducer output, projected to a
reconstructed claim state, renders the IDENTICAL v0.7 film as the golden
`admit_step` state (valid fresh cases). **Receipt-capacity fault is
structurally UNREACHABLE in the composed single-epoch reducer** (MAX_EVENTS ==
MAX_FACTS == 6, facts monotone, ≥1 fact/event ⇒ needed = events − R ≤ 6 − R =
remaining); its mechanism stays gated at the `ic_accept` unit level
(`binding_run3m` B5, 7 event keys). **3b.5f-2b (above) now wires the reducer's
emitted `EpochControl` through `compile_step_v6` into the v0.6 world and folds
the persistent claim/world state over K epochs as one native trajectory.**

---

**SLICE 3b.5f-2a MEASURE PASS_REF_AND_NATIVE (0s, 6 cases) — `admit_ic.py` +
`binding_run3l.py`.** Measure-before-building for the IC lowering: the golden
reducer decides everything downstream from two key comparisons (`min
CandidateKey` for acceptance, key `==` for set distinctness) plus one scalar
(`occ+nnew ≤ cap`, atomic capacity). This sub-slice lowers exactly those three
onto the calculus over the **packed-key representation** — the one
representation choice the ruling left to me: pack each key as ONE fixed-width
unsigned integer, fields MSB→LSB in the SAME order the golden tuple compares
them (`ckey = digest|kind|idx|r0|r1|r2|r3`, 44b; `fkey = writer|seq|ckey`, 52b),
**measured order- and equality-faithful vs the golden Python tuple comparison
(324/324 payload pairs, incl. the 0xf6 collision pair)**. Then `min CandidateKey`
= unsigned `ic_min2(CKEY_W)` (ltu→mux) and distinctness = `dyn_case("eq")`, both
native-gated: M1 candidate-min == golden min (24 pairs); M2 collision 0xf6 packs
DISTINCT, min picks the smaller pkey; M3 fact-key `==` == golden set identity;
M4 recognition via IC eq (distinct→disputed, retransmit→unambiguous); M5 atomic
capacity `fits == (occ+nnew≤6)`; M6 overflow verdict order-independent. Both
golden-repair witnesses are now **pure-term** regressions. BUILD (assembly)
remaining for 3b.5f-2a: occupied-prefix sorted fact/receipt vectors, OBSERVE
compare-shift insert, per-event-group min, MAP → EpochControl, single reducer
native gate through `compile_step_v6`.

---

**SLICE 3b.5f-1 PASS_REF_AND_NATIVE (10s, 16 cases).** The bounded, typed,
prehashed ADMIT semantic core, pinned as a Python golden. The key insight:
**ADMIT is a claim-state reducer that PRODUCES the EpochControl the v0.6 world
already consumes** — the world effect (COMMIT+REACT: rotor/pose/fault) is
already proven, so the whole new surface is
`observed claim batch + persistent ClaimState → EpochControl`. Raw wrt
ACCEPTANCE (the reducer receives UNACCEPTED claims and decides recognition /
acceptance / effect) but NOT raw wrt crypto parsing (claims arrive as canonical
typed PREHASHED envelopes; **no pure-term SHA-256** this slice).

## Two golden repairs GPT-5.6 required before the 3b.5f-2 IC lowering

Both are now permanent battery regressions. GPT-5.6 also ruled the container:
**Option A — occupied-prefix sorted structural vectors** for facts and receipts
(canonical Film order + adjacent equivocations + deterministic scans, free; a
credible bounded sorted-union path). Policy renamed
`admit_digestmin_firstreceipt_v1` → **`admit_candidate_min_firstreceipt_v1`**
because acceptance now orders a full candidate, not just a digest.

- **Correction 1 — reduced-digest collisions are semantically visible.** WD=8
  collides: `SetRotor("sp",(16,0,10,0))` and `SetRotor("sp",(16,1,5,0))` share
  digest **0xf6** (the battery's search rediscovers exactly 0xf6). A digest-only
  identity collapses two distinct payloads into one fact → wrongly
  `unambiguous`, one payload lost, receipt can't name the accepted one. FIX: a
  COMPLETE candidate key with an injective fixture-scoped `payload_key`
  (`SetRotor→(0,spinner_index,r0..r3)`, `ResetFault→(1,orb_index,0,0,0,0)` —
  collision-free by construction). `CandidateKey=(digest,payload_key)`;
  `ClaimFactKey=(writer,seq,digest,payload_key)`; same-batch acceptance = **MIN
  CandidateKey** (digest-min stays primary, payload_key is the tie-break);
  receipts store the full accepted candidate; **recognition counts distinct
  candidate keys** (a collision still reads `disputed`).
- **Correction 2 — capacity exhaustion must be arrival-order independent.** An
  insert-until-full loop kept different facts when the same overflowing batch
  was reversed. FIX: OBSERVE/ACCEPT are **ATOMIC per epoch batch** —
  canonicalize+dedup the batch, drop already-present, sort by ClaimFactKey; if
  the new facts don't ALL fit, latch **`fact_capacity_fault`**, insert NONE,
  create no receipts/effects. The same atomic law governs receipts
  (**`receipt_capacity_fault`**, separate flag; combined `capacity_fault`
  derived for presentation). Never evict, never partially apply. Caps are proof
  parameters (`MAX_FACTS=MAX_EVENTS=6`, added **`MAX_BATCH=4`**), not language
  limits. NB: Option A prepares SET-UNION merge but is NOT yet a full bounded
  CRDT — `unique(left∪right) > MAX_FACTS` is a future distributed-slice choice.

## The model (bounded, canonical, monotone)

- **Payload** `SetRotor(spinner, rotor4) | ResetFault(orb)`; `pdigest` = a
  reduced-width (WD=8) canonical id, a pure function of the canonical payload
  string ⇒ recognition is **arrival-order independent by construction**.
- **ClaimFact** `{event_key:(writer,seq), digest, payload_key, payload}` — a
  bounded canonical SET distinct by **ClaimFactKey `(writer,seq,digest,
  payload_key)`** (Correction 1); equivocation (incl. digest collisions) is ≥2
  facts under one event_key. **Recognition is DERIVED** from distinct candidate
  keys (0→unknown, 1→unambiguous, 2+→disputed), never stored.
- **AcceptanceReceipt** `{event_key, accepted_digest, accepted_payload_key,
  accepted_epoch, outcome}` kept **SEPARATE** from facts
  (`outcome = Applied | Rejected(reason)`); one immutable receipt per event_key,
  **first receipt authoritative**.
- **ClaimState** `{facts[≤MAX_FACTS], receipts[≤MAX_EVENTS],
  fact_capacity_fault, receipt_capacity_fault}`. On exhaustion **never evict /
  never partially apply** (atomic per batch); combined `capacity_fault` derived.

## Acceptance policy `admit_candidate_min_firstreceipt_v1`

Same-batch same event-key multiple distinct payloads → accepted = **MIN
CandidateKey `(digest, payload_key)`** (**order-independent**, collision-safe).
Cross-batch with an existing receipt → keep it; a later conflicting claim joins
the observed set and flips recognition to **disputed** but **never
undoes/retries** the earlier effect. Distinct events apply in
`(sequence, writer, digest, payload_key)` order; two accepted events writing the
same rotor the same epoch → the **later canonical event's** write is committed.
Phases: **OBSERVE → ACCEPT → MAP → [COMMIT+REACT in the v0.6 world] → HASH/FILM**.

- `admit.py` — golden reducer (`admit_step`) + **Film v0.7** (`film_bytes_v7`
  extends v0.6 with `acceptance_policy_id`, both capacity faults, the claim fact
  set with `payload_key`, receipts + accepted candidate + outcomes, derived
  recognition).
- `binding_run3k.py` — **16-case battery**: new unambiguous claim; accepted
  retransmission; same-batch equivocation (candidate-min, host-order
  independent); cross-batch equivocation (first receipt kept); conflicting
  retransmission (monotone set unchanged); recognition convergence (3 arrival
  patterns → same candidates); acceptance separation (two logs retain different
  receipts); later conflict no rollback (committed rotor survives dispute);
  rejected accepted op (Rejected receipt persists, retransmit no retry); two
  distinct rotor events (canonical-last wins); reset claim (Ruling-1 semantics
  via ADMIT); reset+overflow (current overflow relatches); **digest collision
  witness** (Correction 1 — shared digest 0xf6, distinct payloads stay disputed,
  candidate-min pkey wins); **fact capacity atomic + reversed** (Correction 2 —
  overflowing batch rejected whole, reversed == forward, no evict/partial);
  **receipt capacity atomic** (no receipts/controls from an over-capacity accept
  batch, facts kept); **Law 6 witness** (World A no receipt vs World B receipt
  for E → Film v0.7 already differs BEFORE E retransmitted → divergent effect
  licensed). World effect runs through the already-proven `compile_step_v6`; a
  representative native gate confirms `ic_ref == ic32` on the produced controls.

**DEFERRED to 3b.5f-2 (IC lowering):** the persistent in-calculus claim-log
fold and the FULL native gate on a **Scott-encoded bounded sorted claim SET +
receipts** (the hard part — pure-term OBSERVE/ACCEPT/MAP). **DEFERRED further:**
SHA-256 in terms, unbounded maps, STAMP/DELETE, dynamic sockets, claim
replication, receipt merging, rollback, sequencer, signatures. First distributed
rule stays: claim facts merge by **SET UNION**; receipts do **not** blindly merge.

---

# Forge Binding Results v0.17 — fault-reset op executed (GPT-5.6 ruling 1): separate per-orb fault control

**FAULT-RESET PASS_REF_AND_NATIVE (28s).** Per GPT-5.6's ruling, numeric-fault
reset is a **separate per-orb control input**, not part of `RotorConfigInput`:
rotor config targets a **Spinner**, numeric fault belongs to the controlled
**Orb** (it may outlive/lose/change its controller). The v0.6 EpochControl is
now `TUP(rotor_bundle, fault_bundle)`; `fault_bundle` is one
`KeepFault(F) | ResetFault(T)` flag per orb. A **global reset** is user-facing
syntax that **expands to a set of per-orb ResetFault flags** — not a canonical
primitive.

## The safety ordering (COMMIT clears, then REACT ORs)

`ADMIT accepted controls → COMMIT rotor writes AND fault resets → REACT →
latch current arithmetic overflow`. Per orb:
`fault_base = 0 if ResetFault else old_fault; new_fault = fault_base OR
current_epoch_overflow`. So **a reset can never conceal a fault generated in
the same epoch**: reset+overflow → fault stays 1; reset+clean/idle → clears.

- `compiler.py`: `enc_config_bundle(fx, cfgs, resets=None)` now emits the
  EpochControl pair (default `resets=None` → all KeepFault, so slices 3b.5d-2
  and 3b.5e are behavior-identical and stay green ref+native). `compile_step_v6`
  destructures `(ec λrb.λfb.…)`, computes `fault_base = ((reset F) old_fault)`,
  and folds this epoch's overflow into `fault_base` (not `old_fault`).
- `binding_run3j.py` — 8-case battery: (1) idle reset clears an old fault;
  (2) reset + clean rotation clears; (3) reset + overflow relatches immediately
  (the safety property); (4) reset is per-orb (only the target orb clears);
  (5) reset idempotent (resetting a clean fault is a no-op == KeepFault);
  (6) global reset == the set of per-orb resets (identical state); (7)
  persistent fold == harness with a reset landing mid-stream on a fault set
  earlier in the same in-calculus run (`[0,1,1,0,0,0]`, set@1 reset@3 stays 0);
  (8) hard native gate ic_ref == ic32 == harness.
- Reset authority is separate from Spinner configurability; this pre-ADMIT
  slice accepts an already-authorized reset. Under 3b.5f, authorization
  belongs to the accepted `ResetFault` event. Film v0.6 does not record the
  transient reset pulse (it already records the resulting authoritative fault);
  the later claim-aware Film v0.7 records the accepted reset RECEIPT.

**Next: 3b.5f bounded ADMIT semantic core** for `SetRotor`/`ResetFault` —
monotone canonical claim facts, separate immutable acceptance receipts,
digest-min same-batch selection, first-receipt cross-batch, canonical
event-order application, Film v0.7 claim/receipt observability, persistent-fold
parity, hard native gate. Prehashed typed envelopes (no pure-term SHA-256).

---

# Forge Binding Results v0.16 — slice 3b.5e executed: persistent epochs (the v0.6 transition composes in-calculus)

**SLICE 3b.5e PASS_REF_AND_NATIVE (48s).** 3b.5d-2 proved a single v0.6
transition `λcfg.λst → st'`. This slice proves that transition **composes
under the interaction calculus' own reduction**: a world runs **K epochs from
one initial state entirely inside one normalization** — no Python
decode/re-encode between epochs — carrying counters + wires + doors + poses +
**rotors** + faults as pure IC data, and emits the whole film sequence from
that one normal form. Firing is driven by the world's **own clock** (the
periodic pulser through the one-epoch-delayed wire), **not** by manual
per-epoch wire injection.

## The finding

Persistence is **intrinsic to the compiled term**, not an artifact of the
harness re-injecting state. The internally-persistent K-epoch world is
**state-for-state and film-for-film identical** to the harness-stepped world
(which decodes and re-encodes state every epoch), and the identity holds on
the **native** runtime too.

- **The persistent driver** (`binding_run3i.drive_k`) folds the fixed step
  over a fixed pre-encoded config stream: each intermediate state is
  **affine-duplicated** (one copy feeds the next epoch, one copy is emitted),
  producing one term that normalizes to `TUPN([s₁ … s_K])`. State never leaves
  the calculus between epochs.
- **Battery** (K=6): (1) persistence identity — internal fold == harness,
  state + film, every epoch (final pose `(246,0,0,10)` under a genuine
  pulser-driven trajectory); (2) config-stream persistence — a mid-stream
  rotor change composes internally and the rotor field tracks the committed
  value across epochs; (3) sticky-fault persistence — a saturating rotor
  **committed at a firing epoch** latches `numeric_fault` inside the fold
  (`[0,1,1,1,1,1]`) and stays latched == harness; (4) determinism — one driver
  normalized twice → identical film-hash sequence; (5) **multi-controller
  persistence** — two spinners on different pulser periods (2, 3) with distinct
  rotors persist **independently** through the same fold, no cross-contamination
  (`ob0 (246,0,0,10) != ob1 (241,0,0,0)`) == harness; (6) **native hard gate**
  — the internal driver on ic32 == ic_ref == harness, state-for-state.
- **Scope (narrow, per roadmap)**: fixed graph, no ADMIT, no dynamic sockets,
  no claim replication. Stateful rotor changes flow through the fold as a fixed
  pre-encoded config stream. Run: `PYTHONPATH=../runtime/python:../research
  python3 binding_run3i.py` (`TRVM_SKIP_NATIVE=1` skips the native gate).
- **Design note**: because firing carries a one-epoch wire delay and config is
  applied **config→COMMIT→REACT**, a saturating rotor must be **committed at a
  firing epoch** to overflow the reacting rotation (committing it a tick early
  is overwritten by the next epoch's committed rotor before the spinner reads
  it — the same COMMIT-then-REACT ordering certified in 3b.5d-2 case 9).

**Next: raw ADMIT/claim-set lowering** (deferred through 3b.5d-2/3b.5e) — the
first slice to lower an accepted claim set onto compiled world state, or a
multi-orb / multi-controller persistent graph. Measure before building.

---

# Forge Binding Results v0.15 — slice 3b.5d-2 executed: Film v0.6, rotor-as-state (GPT-5.6 ruling 1A)

**SLICE 3b.5d-2 PASS_REF_AND_NATIVE (16s).** The dynamic Spinner (3b.5d-1)
made the rotor flow as data for essentially free (1.00×); this slice makes
the rotor **canonical runtime STATE** and evolves the canonical film
**v0.5 → v0.6**, per GPT-5.6's Option **1A** ruling: every v0.6 Spinner
carries its current rotor as state (a `TUP4×TUPw` field); the fixture rotor
is **initialization data only**. "Fixed" vs "configurable" is a **permission
distinction** enforced at the config-acceptance gate — **not** two state
layouts or two film paths. v0.5 is retained **replay-only**.

## The authority model (preserved + redefined)

- **Anchor invariant redefined + preserved**: `model_rotor == exact_lift(circuit_rotor_STATE)`
  (was `exact_lift(fixture_constant)`). The rotor is **assigned, never
  composed**, so a plain sign-extend-then-`<<(32−n)` rescale is exact — **no
  separator opens on the rotor** (contrast the POSE, which IS composed and
  does separate at Q32.32, slice 3b.5c). `fixture.lift_rotor` + a direct
  `model_projection_v6` assertion every epoch.
- **Authoritative sticky fault (the prerequisite fix)**:
  `binlib.dyn_rot_step_forge_dyn_f(w,n)` = the fully-dynamic `λR.λP` forge
  step that now **returns `RotationResult{pose:Quat4, overflow:Bool}`** —
  each lane's wide-MAC overflow flag is kept and the four are OR-reduced.
  The v0.6 transition latches `numeric_fault = old OR overflow`, **sticky**
  until an explicit reset op; Film v0.6 records it.
- **Config semantics**: `RotorConfigInput = NoChange | SetRotor(typed)`;
  transition order = **accepted config write → COMMIT (to rotor state) →
  REACT (rotate reading the just-committed rotor)**, so config + hot signal
  in the **same epoch → the NEW rotor controls the rotation** (case 9). A
  fixed spinner rejects rotor writes with a typed `RotorConfigError`; a
  configurable one accepts **without kernel replacement**; wrong
  geometry/range is rejected. This slice applies an **already-accepted**
  config to compiled world state; raw ADMIT/claim-set lowering stays
  **deferred** (GPT).

## What the battery proves (`binding_run3h.py`, all 15 + a Law-6 witness)

1 initial-construction (state rotor == fixture init, film v0.6) · 2 film
sensitivity (same pose, diff rotor → diff film) · 3 future sensitivity
(same hot signal, diff rotor → diff next pose) · 4 runtime rotor change
(one term, 5 rotors) · 5 no-recompilation (no rotor value baked in) · 6
model anchor (model Q32.32 == exact lift of circuit rotor STATE at init +
after config; a desynced rotor is rejected) · 7 corrupt state (tampered
rotor fails boundary-film parity) · 8 no-signal config (rotor commits,
pose unchanged) · 9 config+signal same epoch (committed rotor controls) ·
10 fixed spinner (SetRotor typed-rejected; NoChange still accepted) · 11
configurable spinner (accepted, applied on the same term, no swap) · 12
fault (saturating rotor latches fault=1; sticky across firing + idle) ·
13 type mismatch (wrong lane count / out-of-range rejected) · 14
determinism (same init+config stream → same film-hash sequence) · 15
**NATIVE hard gate** (4-epoch config trajectory `ic_ref == ic32`, rotor +
pose + fault, epoch for epoch) · **L6** (worlds agreeing on
pose/clock/wire/controller but R1≠R2 → v0.6 films MUST differ).

New surface: `binlib.dyn_rot_step_forge_dyn_f`; `compiler.compile_step_v6`,
`enc_state_v6`/`dec_state_v6`, `enc_rotor_config`/`enc_config_bundle`,
`accept_rotor_config`/`RotorConfigError`, `_v6_fields`; `fixture`
`configurable` permission + `is_configurable`/`orb_of`/`lift_rotor`/
`init_state_v6`/`state_to_film_args_v6`/`model_projection_v6`;
`film.film_bytes_v6`/`film_hash_v6` ("FILM v0.6"). Reproduce:
`PYTHONPATH=../runtime/python:../research python3 binding_run3h.py`
(`TRVM_SKIP_NATIVE=1` skips the native gate). Next: **3b.5e persistent
epochs** (state tuple carries clocks + wires + doors + relays + poses +
rotors + numeric faults; K epochs from one initial state, compare
harness-stepped vs internally-persistent v0.6 world epoch for epoch).

---

# Forge Binding Results v0.14 — slice 3b.5d-1 executed: the dynamic Spinner — rotor-as-data is essentially free

**SLICE 3b.5d-1 PASS_REF_AND_NATIVE (60s).** The 3b.5c pose authority bakes
a *constant* rotor into the circuit (`dyn_rot_step_forge`); a rotor change
needs a recompile (the 3b.5a EV_CONFIG kernel cache, keyed by rotor bytes).
This slice makes the rotor flow as **data**: `binlib.dyn_rot_step_forge_dyn`
is `λR.λP` — both rotor and pose are runtime TUP4 — so **one compiled term
applies any rotor with no recompilation**, under the same shipping forge
wide-MAC policy.

## What the battery proves (`binding_run3g.py`)

- **A) golden == ic_ref == ic32**: 18 (rotor,pose) cases at Q4.4 + Q8.8,
  fault 0; wide-MAC saturation latches a fault.
- **B) rotor-as-data == baked-in constant rotor**: the dynamic path is
  bit-identical to `dyn_rot_step_forge` for the same rotor, both widths.
- **C) runtime rotor change**: ONE compiled term, **5 distinct rotors**,
  each == its golden — the dynamic Spinner, **no recompile**.
- **D) cost (measure before building)**: Q4.4 step is **dynamic-rotor
  156162 vs constant-rotor 155748 interactions = 1.00×** — flowing the
  rotor as data is **essentially free** (~0.3%). This decisively motivates
  wiring it into the fixture (3b.5d-2): the flexibility (runtime rotor
  change, no kernel cache keyed by rotor bytes) costs almost nothing.
- **E) NATIVE GATE (hard)**: dynamic forge step @Q4.4+Q8.8 + a runtime
  rotor change through `ic32` == golden.

New surface: `binlib.dyn_rot_step_forge_dyn(w, n)` (fully-dynamic forge
wide-MAC quaternion step, reuses `dyn_mac`); `binding_run3g.py` (battery).
Reproduce: `PYTHONPATH=../runtime/python:../research python3
binding_run3g.py` (`TRVM_SKIP_NATIVE=1` skips the native gate). Next:
**3b.5d-2** — carry the rotor as circuit STATE, EV_CONFIG as a data write
(not a recompile) — then **3b.5e persistent epochs**.

---

# Forge Binding Results v0.13 — slice 3b.5c executed: the typed Q32.32 pose-authority bridge, one forge authority, the shadow dict gone

**SLICE 3b.5c PASS_REF_AND_NATIVE (70s).** The compiled IC circuit now
carries a **single real pose authority** under the shipping Spinner policy
`forge_motor_widemac_tz_sat_v1` (wide-MAC: full-precision products, ONE
toward-zero shift, ONE saturation). The frozen `proc-e2.3` oracle
(`e2_model.qmul`, legacy per-product trunc0) is **demoted to an
EVENT/STRUCTURE oracle** — it defines *when* a rotation fires, not the pose
*value*. This is **Option A** of the round-13 policy fork (user decision
2026-07-21): no `proc-e2.3` edit; the shipped pose value differs from the
frozen model's by the certified separator — **accepted and certified, not
equal**. The bridge certifies a *difference*.

New surface: `binlib.golden_rot_forge` / `binlib.dyn_rot_step_forge` (the
forge wide-MAC quaternion rotor step, golden + λP IC term, reusing
`dyn_mac`); `compiler.compile_step(fx, pose_policy=...)` selects `legacy`
(unchanged proc-e2.3-value path, still default) or `forge` (the new Q32.32
authority); `binding_run3f.py` (the battery). **The shadow `poses` dict is
gone**: the circuit's own state IS the pose, value-locked to the forge
golden across a live model run.

## What the battery proves

- **A) forge step golden == ic_ref == ic32**: 18 (rotor,pose) cases at
  Q4.4 + Q8.8, fault 0; a wide-MAC lane that overflows **clamps and latches
  a fault** (the saturation the legacy policy lacks).
- **B/C) single forge authority, no shadow dict** (T=45 live proc-e2.3
  run): the compiled circuit's self-carried pose is **value-locked to the
  forge golden every epoch**, and it fires in **exact event-parity with
  proc-e2.3** (15 rotations, same epochs). The model (legacy) supplies only
  *when*; the circuit supplies *what*. Same facts compel the same recognized
  behavior; the value is independently the forge law.
- **D) certified Q32.32 value-separator** (20,000 Z90 composes, authority
  width): forge ≠ legacy **from epoch 2**; lane-0 delta **2066 ULP** at 20k;
  forge drift **−1.919083e-05** vs legacy **−2.015289e-05** (the ledger
  separator, reproduced to 1e-15). The bridge **certifies the DIFFERENCE** —
  the round-12 "prove Q32.32 equality" expectation is *refuted* by the
  separator, exactly as the 3b.5c blocker predicted; the certificate is the
  honest artifact.
- **E) typed Q32.32 ↔ proxy bridge**: the proxy rotor **lifts exactly** to
  Q32.32 (`<<(32−n)` — the anchor law `fixture.model_projection` already
  asserts); **one** forge step commutes with the rescale on aligned lanes;
  the long-horizon separator (D) is where the widths part. The
  proxy/Q32.32 BindingWorld split is now **explicit**: proxy is a typed
  narrowing of the Q32.32 authority.
- **F) NATIVE GATE (hard)**: the forge rotor step at Q4.4 + Q8.8 through
  `ic32` == golden; **8 epochs of the compiled forge authority** through
  `ic32`, value-locked — 0 mismatches.

## The certificate (typed, shipped)

| claim | status |
|---|---|
| event-parity to proc-e2.3 | **exact** — circuit fires iff the model fires (15/15 epochs, T=45) |
| pose authority | **single, forge wide-MAC**, carried by the circuit; **no shadow `poses` dict** |
| value vs legacy @ small width | agree (proxy) |
| value vs legacy @ Q32.32 | **certified-different**: epoch-2 divergence, 2066 ULP @20k, drift separator reproduced |
| proxy ↔ Q32.32 | typed exact rotor lift; one-step rescale-commutes; long-horizon separation is the certificate |
| golden == ic_ref == ic32 | forge step + compiled authority, hard native gate green |

Slice 3b.5c is complete. The legacy `pose_policy` default keeps 3b.5a
(`binding_run3e.py`) green unchanged (PASS_REF_ONLY re-verified). Reproduce:
`PYTHONPATH=../runtime/python:../research python3 binding_run3f.py`
(`TRVM_SKIP_NATIVE=1` skips the native gate). Next: **3b.5d dynamic
Spinner**, then **3b.5e persistent epochs**.

---

# Forge Binding Results v0.12 — slice 3b.5b-3 executed: the normalization operator, built against the datum, ref+native green

**SLICE 3b.5b-3 PASS_REF_AND_NATIVE (13s).** The reserved
`forge_motor_renorm_tz_sat_v1` is now a first-class IC operator, gated
golden → ic_ref → ic32, and it arrests the 3b.5b-2 drift. Designed
*against the measured datum*, not guessed: first-order (Newton)
renormalization, **no sqrt** — the per-step drift near unit is small, so
the scale `s = sat_w((3·ONE² − norm2) >> (n+1))` (toward zero) applied to
every lane under the shipping wide-MAC policy (exact product, ONE
toward-zero shift, ONE saturation) is exactly the tool the data indicates.
`norm2` is the real-norm² (rotor lanes 0..3 squared) at full width
`Wn = mac_headroom(w,4)`; scale-overflow, any lane-overflow, and the input
fault all OR into the ninth-slot `numeric_fault`.

## What the battery proves

- **golden == ic_ref**: 25/25 lane-exact + fault (rotor sweep + random
  motors); input fault propagates through the operator.
- **drift ARREST** (renorm-every-step vs uncorrected worst, all
  precisions): Q4.4 90.23% → 24.61% (3.7×), **Q8.8 38.93% → 1.56% (25×)**,
  **Q16.16 0.40% → 0.0062% (64×)**. The operator strictly reduces
  worst-case norm error at every precision; at practical widths it holds
  the rotor to a fraction of a percent.
- **Properties**: near-unit renorm is non-worsening; a collapsed rotor
  recovers toward unit (real-norm² 64 → 121 of ONE²=256 at Q4.4); a large
  translational lane (which does not enter norm², so the scale stays >ONE)
  latches the lane-overflow fault. *Design note recorded: the first-order
  scale itself is bounded ≈3·ONE/2 and cannot saturate — only lane scaling
  can fault.*
- **NATIVE GATE (hard)**: 5 renorms + 1 fault-propagation through `ic32` —
  0 mismatches vs `golden_renorm`.

New surface: `motor8.golden_renorm` (exact, reuses `golden_mac`),
`motor8.dyn_motor_renorm` (the λM 9-tuple IC term), `motor8_renorm_run.py`
(the battery). The composition rulepack keeps `normalization =
none_in_composition` (renorm is a *separate* named op, applied by the
caller when it chooses); slice 3b.5b (Motor8) is now complete —
composition, drift, and normalization all ref+native green. Reproduce:
`PYTHONPATH=../runtime/python:../research python3 motor8_renorm_run.py`.

---

# Forge Binding Results v0.11 — slice 3b.5b-2 executed: the drift is measured, the collapse is named, normalization is reserved

**SLICE 3b.5b-2 PASS_MEASUREMENT — measurement only, per the verdict
("Do not normalize inside the first composition battery; 3b.5b-2 measures
drift; a named normalization operation with its own film-visible policy
comes after"). This slice quantifies the datum a later slice must
correct, so the correction is designed against a number.**

The drift metric is proc-e2.3's convention lifted to the motor:
`(motor_norm2_real(pose) − ONE²)/ONE` in ULP-relative units. The motor
"norm" is the study number `M~M = a + b·e0123` (`reverse` flips grade-2
lane signs); its REAL part (lane 0) is the Euclidean rotor norm², its
IDEAL part (lane 7) is the rigid-motion coupling a unit motor holds at 0.
On the rotor subalgebra `motor_norm2_real` IS the quaternion norm² —
asserted here (52 rotors) — so the number is directly comparable to the
ledger's −2.015289e-05 Q32.32 rotor drift.

## What was measured

- **Single-rotor quantization floor** (one encode, no composition): max
  +1.125e+00, mean +4.81e-01 ULP-rel — the irreducible per-rotor error.
- **Composition drift, Q4.4, rotor(11.25°) ×128**: **−14.4375 ULP-rel =
  −90.2% of unit norm², fault 0** — toward-zero truncation is *biased*,
  so the rotor bleeds magnitude and **collapses to a sub-unit fixed point**
  (drift plateaus by step ~32: +0.25 → −5.75 → −14.44 → −14.44 → −14.44).
  This is the headline: unnormalized fixed-point rotor composition does
  not merely wander, it *decays into a stable sub-unit attractor*.
- **Same trajectory, Q8.8 ×128**: −38.9% of unit norm² — **relative decay
  2.3× smaller** than Q4.4 (precision helps, but 39% loss over 128 steps
  still demands normalization).
- **Rigid (ideal-part) constraint**: for a screw (rotor·translator) ×32
  the study-number ideal part **held at exactly 0** in this lattice — the
  second invariant a normalizer must protect, currently clean.
- **IC == golden along the trajectory** (6 steps through `ic_ref`): the
  drift is a property of the *proven* policy, not a harness artifact — the
  golden==IC chain from 3b.5b-1 is unbroken for these exact motors.

## The reserved target

A unit motor must hold real-norm² == ONE² (ideal 0). Measured deficit to
correct at Q4.4/×128 is −14.4375 ULP-rel. Normalization policy **reserved,
not built here**: `forge_motor_renorm_tz_sat_v1` — slice 3b.5b-3, designed
against this datum (first-order renormalization is the indicated tool: the
per-step drift near unit is small, so a scalar ≈ 1/‖M‖ correction applied
periodically fits the measured regime; a full rsqrt is not warranted by
the data).

New surface: `motor8.reverse` / `motor_norm2` / `motor_norm2_real`;
`motor8_drift.py` (the measurement battery). Reproduce:
`PYTHONPATH=../runtime/python:../research python3 motor8_drift.py`.

---

# Forge Binding Results v0.10 — slice 3b.5b-1 executed: the eight-lane Motor8 composes, wide-MAC policy, ref+native green

**SLICE 3b.5b-1 PASS_REF_AND_NATIVE (373s), first green run, ten battery
sections.** The even subalgebra of 3D PGA Cl(3,0,1) — the 8-blade motor
`[1, e23, e31, e12, e01, e02, e03, e0123]` — now composes as a pure IC
term under the shipping `forge_motor_widemac_tz_sat_v1` policy. Signs are
DERIVED from a single canonical blade multiplication under the metric
(e0²=0, eᵢ²=+1, all anticommute), not read off lane names; `e31 = −e13`
is the only signed canonical. Each output lane is a wide-MAC over its
surviving signed blade products (per-lane term counts [4,4,4,4,8,8,8,8],
so Wacc = 2w+3 = 19 bits at w=8, the strict no-wrap bound), one
toward-zero shift, one symmetric saturation; the eight lane overflow bits
OR into the ninth-slot authoritative `numeric_fault`. Content-addressed
rulepack id `5d5b1231ac6cb1bb` covers basis order, metric signature, full
multiplication table, lane width, fraction bits, rounding, saturation,
and normalization=`none_in_composition`.

## What the battery proves (ref, then hard native gate)

- **64 basis-blade pairs**: table closure exact vs `golden_geo`; each
  product single-lane or degenerately annihilated; 48/64 nonzero.
- **Identity both sides**: I∘B == B∘I == B lane-exact, fault 0.
- **Pure rotor composition**: ref == golden across 25 rotor pairs; the
  rotational bivectors + scalar reproduce the independent Hamilton
  wide-MAC oracle under the embedding I=−e23, J=−e31, K=−e12
  (`QUAT_EMB=(1,−1,−1,−1)`); translational lanes stay 0; Z90 trajectory
  ×16 value-exact (~153k interactions/compose).
- **Pure translator composition**: stays in the translator subspace
  (rotational+pseudoscalar lanes 0), ref == golden.
- **Mixed rotor/translator**: ref == golden; noncommutativity witnessed
  (36/40 pairs A∘B ≠ B∘A).
- **Overflow/saturation**: all-MAX products latch fault=1 and clamp ==
  golden; random wide products ref == golden through saturation.
- **Per-lane wide accumulator oracle**: |acc| < 2^(Wacc−1) by
  construction and over 200 adversarial motors.
- **NATIVE GATE (hard)**: 5 motor products through `ic32` — 0 mismatches
  vs `golden_fixed`.

New surface: `binlib.dyn_mac(w,n,signs)` (general k-term wide-MAC,
arbitrary-arity generalization of `dyn_mac4`, verified vs `golden_mac`
across k∈{1,2,3,5,8}); `motor8.py` (algebra, derived GEO_TERMS, goldens,
rulepack, `dyn_motor_mul` constant-A-onto-dynamic-B compiler with
zero-lane fold at emit time); `motor8_run.py` (the battery).
Normalization is deliberately absent (verdict) — 3b.5b-2 measures drift
before any named normalization op is introduced.

## Reproduce (3b.5b-1)

```
cd forge
PYTHONPATH=../runtime/python:../research python3 motor8_run.py            # ref + native, 373s
PYTHONPATH=../runtime/python:../research TRVM_SKIP_NATIVE=1 python3 motor8_run.py   # ref only
```

---

# Forge Binding Results v0.9 — round 12 executed: the Spinner is a fixture citizen, film v0.5 carries pose

**SLICE 3b.5a PASS_REF_AND_NATIVE (146s), first run, all eight battery
items. The Spinner is now first-class: film v0.5 carries authoritative
pose state (numeric-policy id, lane geometry, big-endian
two's-complement lanes, controller relationship, fault latch), and the
compiled epoch term applies the rotor by Scott FUNCTION-selection on
the spinner's in-wire — the pose is consumed exactly once, and the
dead rotation branch erases before its interior reduces: idle epochs
cost 39 interactions inside a 1 MB term; firing epochs ~76.5k (Q4.4) /
~305k (Q8.8). Measured, not assumed.**

## Round-12 corrections, executed first

Transitivity wording corrected to the CONDITIONAL form (demonstrated
small-width equality + implication at Q32.32; closure assigned to the
3b.5c typed bridge). Separator table now carries the canonical
corrected-horizon figures: **19,979/20,000 divergent, wide-MAC
−1.919083e-05 vs oracle −2.015289e-05** — my own rerun log already
contained them; the ledger had quoted the stale pre-fix run.
E2_RESULTS retitled **v2.3 — Native Once Refreeze (28/28)**. Policy
identities registered in binlib: `legacy_spinner_pp_tz_nosat_v1`,
`forge_motor_widemac_tz_sat_v1`.

## The width-scoping decision (stated for ratification)

The binding Spinner is a Forge-layer object at fixture-declared proxy
width whose pose semantics are the PARAMETRIC ORACLE POLICY (proven ≡
`e2_model.qmul`, 3b.4 §A). The real Q32.32 World runs in lockstep as
the timing/structure anchor; its rotor is the exact `<<(32−n)` rescale
of the filmed proxy lanes, **asserted at every projection** (config
integrity has teeth). Q32.32 value parity closes at 3b.5c per the
round-12 ruling. Film v0.5's policy-id + lane-geometry fields make the
width explicit so nothing is silently conflated.

## Slice 3b.5a battery (all PASS, first run)

| item | result |
|---|---|
| pulser→wire→spinner latency+parity, Q4.4 T=45 | films exact; rotations at the closed form {4,7,…}; **idle 39 ints, firing 76,488–77,638** |
| independent init | boundary parity holds; **corrupted pose lane FAILS it** (teeth) |
| Q8.8 parity T=16 | films exact; firing 304,025–306,977 ints |
| dynamic multi-rotation (period 2, T=30) | 15 rotations, films exact every epoch |
| controller exclusivity + release | static double-socket → typed ValueError; live second LINK rejected as `controlled`; DELETE frees; relink succeeds |
| EV_CONFIG rotor at epoch 10 | model CFG (anchor rescale) + kernel swap keyed by (policy, rotor bytes); films exact across the change |
| determinism | same artifact+inputs twice → identical film sequences |
| NATIVE GATE (hard) | 8 full epochs of the 1 MB spinner term through ic32, films exact |

Overflow law status, per the ruling: the legacy policy has no
saturation; the film's fault bit is present and 0, wired for the
wide-MAC policy where it becomes authoritative (3b.5b).

## Ripple regressions under film v0.5

The version line bumps every film hash; both sides bump together. One
real break found and fixed: `state_from_projection` unpacked a
5-tuple — now accepts the v0.5 seven-tuple, ignoring pose sections in
discrete-only slices. run3e **PASS_REF_AND_NATIVE** (146s) · run2
**PASS** · run3 **PASS** · run1 smoke + NEG 4/4 · run3d rerun **PASS_REF_AND_NATIVE** (rc=0 under the v0.5 tree) ·
oracle 28/28 and `make test` unchanged (film is binding-layer only).

## The policy finding, reconciled with round 11's freeze

Round 11 froze the wide-MAC (exact products → sign-extend → ±
accumulate → ONE shift → ONE saturation) as **Forge numeric law for new
numerics**. The spinner is not new numerics: it is governed by the
frozen v2.2 oracle, whose policy is per-product truncation. Both live
in `binlib` (`dyn_mac4` = the law; `hcomp_case`/`rot_step_case`/
`dyn_rot_step` = the oracle's policy), and the live separator on the
real trajectory shows the stakes: **first divergence at rotation 2;
19,979 of 20,000 rotations diverge; wide-MAC drift −1.919083e-05 vs
the oracle's −2.015289e-05** (canonical, at the corrected horizon).
The policies are one ULP apart per component and ~5% apart in
century-scale drift.

## The K off-by-one — a lesson in not extrapolating a schedule

My first drift replication used K=19,999 rotations and missed the
documented figure in the 5th significant figure. The long run executes
epochs tc = 2 … **100,001** (build primes two epochs), so rotations at
tc≥6, (tc−6)%5==0 count to **K=20,000**. The fix is not a formula
patch but a method change: section B1 now validates the schedule and
function against the ACTUAL model — 200 epochs, pose exact every epoch
— and only then extrapolates. **K=20,000 → drift −2.015289e-05,
matching the documented figure to all printed digits (tol 1e-11).**

## Slice 3b.4 battery

| section | result |
|---|---|
| A. parametric policy ≡ `e2_model.qmul` at Q32.32, 2000 random quats | **PASS** |
| B1. schedule+function vs the actual model, 200 epochs pose-exact | **PASS** |
| B2. drift replication, K=20,000 → **−2.015289e-05** ≡ documented | **PASS** |
| C. policy separator LIVE on the real trajectory | measured (above) |
| D. hcomp (per-product policy, in-range flag) ×400; **const rotation trajectories pose-value-exact**: Q4.4 T=64, Q8.8 T=24 | **PASS** |
| E. **DYNAMIC rotation trajectories pose-value-exact**: Q4.4 T=32, Q8.8 T=8 | **PASS** |
| F. NATIVE GATE (hard): const ×6 + dynamic ×3 through ic32 | **PASS, 0 mismatches** |
| G. transitivity verdict (CONDITIONAL, per round 12) | the tested lowering implements the oracle's policy at Q4.4/Q8.8 (D,E) ∧ the same parametric policy ≡ oracle at Q32.32 (A) ∧ reproduces the documented drift (B) ⇒ **a correct Q32.32 instantiation of this lowering would reproduce the drift** — a demonstrated equality at small widths plus an implication at target width; Q32.32 parity closes at the 3b.5c typed bridge |

## The measured quaternion numbers (the round-11 optimization input)

Per rotation (8 nonzero products for ROT_Z90; zero-rotor products
skipped at emit — fixture constants compile in):

| form | Q4.4 | Q8.8 |
|---|---|---|
| constant | 71,056–72,392 (mean **71,216**) | 285,480–289,176 (mean **287,460**) |
| dynamic pose | 76,286–77,600 (mean **76,607**) | 303,998–307,526 (mean **305,938**) |

The dynamic tax at rotation scale is ~7%. The reviewer's 16-product
estimate (~577k) halves under zero-skipping for this rotor; a dense
rotor would land near it. **This is the datum the round-11 ruling
deferred the optimization decision to.**

## Round-11 conditions, executed

Registry **completed**: `mul_wide`/`shift_tz` registered (flat,
no-flag), `mac` registered (nested); **`dyn_mac4` promoted into binlib**
as the reusable frozen-policy combinator (verified ×8 vs golden);
`mac_headroom(w,k)` makes the accumulator-cannot-wrap claim an
**executable assertion** (Wacc = 2w+⌈log₂k⌉, strict bound checked).
`dyn_take_value` remains documented legacy/flat-only. Eager-class cost
claims formally moved to the packed-net venue (two-field cost records:
logical firings + wall-clock under named scheduler). **Native model
Once: narrow unfreeze granted — executing next**; until it lands, Law 6
remains horizon-scoped and the stale fixture.py sentence stands
condemned.

## Regressions — ALL rerun under the native-Once tree

run3d **PASS_REF_AND_NATIVE** (417s; drift −2.015289e-05 unchanged, as
the schedule requires) · run3c **PASS_REF_AND_NATIVE** (134s) · run3b
**PASS** (345s) · run3 **PASS** (once-heavy slice) · run2 **PASS** ·
run1 smoke + NEG 4/4 · oracle **28/28** · `make test` 13/13 (rulepack
hash moved with the edit, as content-addressing requires).

## Laws

1–7 unchanged. Round-11 commentary on Law 5: *two numeric policies are
two meanings — an encoding may not switch between them silently; a
policy change is an explicit act with a measured separator.*

## Deferred, stated

3b.5 Motor8 integration (film/pose fields,
compiler spinner support, constant-rotor multiplier specialization as a
measured optimization) — **gated on round-12 review with the quaternion
numbers above as input**. w-row/Booth multiplier for the product path.
Packed-net eager measurement. Framed WireIdentity; structural lowering;
persistent loop; ADMIT on-reducer; CUDA.

## Reproduce

```
cd forge
python3 binding_run3d.py     # 3b.4 quaternion proxy (~4-5 min)
python3 binding_run3c.py && python3 binding_run3b.py
python3 binding_run3.py && python3 binding_run2.py
python3 binding_run.py && python3 binding_run.py NEG
python3 e2_run.py && cd .. && make test
```
