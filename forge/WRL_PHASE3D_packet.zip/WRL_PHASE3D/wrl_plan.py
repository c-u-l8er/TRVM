"""wrl_plan.py v0.1 -- CompilePlanV1: the deterministic, backend-neutral
compile plan (Phase 3D-1/3D-2).

GPT-5.6's Phase 3D ruling: extract a deterministic `CompilePlanV1` consumed by
the EXISTING backend machinery; make both the frozen Forge IR and the legacy
Fixture produce that SAME plan; then feed the plan to `compile_step_v6` through
a NON-TEST shim so the plan -- not the Fixture -- becomes the production
lowering contract, and the Fixture is retained only as an independent oracle.

A CompilePlanV1 is a validated, JSON-plain preparation of a sealed semantic
artifact. It carries exactly the structural facts the compiler reads, in a
canonical (declaration-order-independent) form, PLUS three deterministic
signatures that fingerprint the encoded-state layout, the epoch-input shape and
the film observable. It MUST NOT contain any backend lowering result -- no Scott
encoding, DUP labels, generated variable names, tuple nesting, one-hot/binary
counter bit layout, native memory offsets or CUDA layouts. Those are produced by
`compile_plan_to_ic` (the reference/native IC lowering) and belong to the
BackendArtifactID, not the plan.

  fixture_to_compile_plan_v1(fx, sem_id)     Fixture  -> CompilePlanV1
  artifact_to_compile_plan_v1(sealed|art)    Forge IR -> CompilePlanV1  (same!)
  compile_plan_to_ic(plan, lowering_profile) CompilePlanV1 -> (ic_term, fields)
  compile_plan_digest(plan)                  test-only canonical plan hash

Identity law (GPT-5.6):
  * SemanticArtifactID  -- moves iff the semantic graph moves;
  * CompilePlanDigest   -- test-only; moves iff the plan moves (== semantic);
  * BackendArtifactID   -- moves iff the SemanticArtifactID OR lowering profile
                           moves.
"""
import os
import sys
from collections import namedtuple

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
sys.path.insert(0, os.path.join(_HERE, "..", "runtime", "python"))
sys.path.insert(0, os.path.join(_HERE, "..", "research"))
import wrl_canonical as WC
import compiler as C
from fixture import ONEHOT_MAX          # representation THRESHOLD constant only
                                        # (a number, NOT the Fixture class): the
                                        # onehot/binp choice is a compiler-layer
                                        # rule, kept in the shim, out of the plan

COMPILE_PLAN_VERSION = "compileplan.v1"

WRL_BAD_COMPILE_PLAN = "WRL_BAD_COMPILE_PLAN"

CompiledProgram = namedtuple("CompiledProgram",
                             "plan ic_term fields backend_artifact_id")


# ===================================================================
# _PlanView -- the NON-TEST compiler shim.
#
# It duck-types the exact read interface `compile_step_v6`, `enc_state_v6`,
# `dec_state_v6`, `enc_config_bundle`, `state_to_film_args_v6` and `init_state_v6`
# consume from a Fixture, reconstructed from a CompilePlanV1. It is NOT the
# Fixture class (so the Fixture stays an independent oracle) and it performs NO
# construction-time validation or model building -- it is a pure projection of an
# already-sealed, already-validated plan. The method bodies mirror the Fixture's
# read-only projections; the onehot/binp representation choice (the ONLY policy
# here) reuses the shared ONEHOT_MAX threshold.
# ===================================================================
class _PlanView:
    __slots__ = ("pulsers", "spinners", "orbs", "relays", "doors",
                 "edges", "sockets", "_conf")

    def __init__(self, plan):
        self.pulsers = {p["id"]: tuple(p["clock"]) for p in plan["pulsers"]}
        self.spinners = {s["id"]: (s["w"], s["n"], tuple(s["rotor"]))
                         for s in plan["spinners"]}
        self._conf = {s["id"]: bool(s["configurable"])
                      for s in plan["spinners"]}
        self.orbs = list(plan["orbs"])
        self.relays = list(plan["relays"])
        self.doors = list(plan["doors"])
        self.edges = [tuple(e) for e in plan["signal_edges"]]
        self.sockets = [tuple(x) for x in plan["socket_controls"]]

    def kinds(self):
        k = {r: "pulser" for r in self.pulsers}
        k.update({r: "relay" for r in self.relays})
        k.update({r: "door" for r in self.doors})
        k.update({r: "spinner" for r in self.spinners})
        k.update({r: "orb" for r in self.orbs})
        return k

    def controller_of(self, orb):
        for (s, o) in self.sockets:
            if o == orb:
                return s
        return ""

    def orb_of(self, spinner):
        for (s, o) in self.sockets:
            if s == spinner:
                return o
        return ""

    def is_configurable(self, spinner):
        return self._conf.get(spinner, True)

    def wire_role(self, s, d):
        return "w__%s__%s" % (s, d)

    def wires(self):
        return sorted(self.wire_role(s, d) for s, d in self.edges)

    def layout(self):
        return (sorted(self.pulsers), self.wires(), self.doors, self.relays)

    def counter_spec(self, role):
        spec = self.pulsers[role]
        if spec[0] == "once":
            e = spec[1]
            return ("once", e, max(1, (e + 1).bit_length()))
        _, p, ph = spec
        if p <= ONEHOT_MAX:
            return ("onehot", p, ph)
        return ("binp", p, ph, p.bit_length())

    def in_wires(self, role):
        return sorted(self.wire_role(s, d) for s, d in self.edges
                      if d == role)

    def out_wires(self, role):
        return sorted(self.wire_role(s, d) for s, d in self.edges
                      if s == role)


# ===================================================================
# Deterministic signatures -- the encoded-state layout, the epoch-input
# shape and the film observable, fingerprinted from a plan view. These are
# structural contracts (no representation bits, just the SHAPE) so that
# presentation-only edits leave them fixed while any semantic change moves them.
# ===================================================================
def _state_layout_signature(view):
    ppl, wires, doors, relays = view.layout()
    layout = []
    for r in ppl:
        layout.append(["counter", r, list(view.counter_spec(r))])
    for f in wires:
        layout.append(["wire", f])
    for f in doors:
        layout.append(["door", f])
    for f in relays:
        layout.append(["relay", f])
    for o in view.orbs:
        s = view.controller_of(o)
        w_ = view.spinners[s][0] if s else 8
        layout.append(["pose", o, w_])
        layout.append(["fault", o])
    for o in view.orbs:
        s = view.controller_of(o)
        if not s:
            continue
        layout.append(["rotor", s, view.spinners[s][0]])
    return "slay-" + WC._sha(WC.serialize_artifact(layout))


def _epoch_input_signature(view):
    ctrl = [view.controller_of(o) for o in view.orbs if view.controller_of(o)]
    rbundle = [[s, view.spinners[s][0]] for s in ctrl]
    fbundle = list(view.orbs)
    return "epin-" + WC._sha(WC.serialize_artifact([rbundle, fbundle]))


def _observable_signature(view):
    obs = []
    for r in sorted(view.pulsers):
        obs.append(["pulser", r, view.pulsers[r][0]])
    for r in view.doors:
        obs.append(["door", r])
    for r in view.relays:
        obs.append(["relay", r])
    for wr in view.wires():
        obs.append(["wire", wr])
    for s in sorted(view.spinners):
        w_, n_, _ = view.spinners[s]
        obs.append(["spinner", s, w_, n_, view.orb_of(s),
                    "configurable" if view.is_configurable(s) else "fixed"])
    for o in view.orbs:
        s = view.controller_of(o)
        w_ = view.spinners[s][0] if s else 8
        n_ = view.spinners[s][1] if s else 4
        obs.append(["orb", o, w_, n_, s])
    return "obsv-" + WC._sha(WC.serialize_artifact(obs))


# ===================================================================
# The single canonical plan builder. Both entry points normalize their
# source into these parts and call it, so the two plans are BYTE-identical.
# ===================================================================
def _plan_from_parts(sem_id, profile_id, semantic_policies, pulsers, relays,
                     doors, spinners, orbs, sig_edges, sockets, conf):
    """pulsers: {id: clock-tuple}; spinners: {id: (w, n, rotor-tuple)};
    conf: {spinner_id: bool}; relays/doors/orbs: [id]; sig_edges/sockets:
    [(src, dst)]. Everything is canonicalized (sorted) so declaration order
    cannot leak into the plan."""
    order = sorted(list(pulsers) + list(relays) + list(doors)
                   + list(spinners) + list(orbs))
    plan = {
        "compile_plan_version": COMPILE_PLAN_VERSION,
        "semantic_artifact_id": sem_id,
        "profile_id": profile_id,
        "rulepack_id": semantic_policies["rulepack_id"],
        "numeric_policy_ids": sorted(semantic_policies["numeric_policy_ids"]),
        "admit_policy_id": semantic_policies["admit_policy_id"],
        "film_schema_id": semantic_policies["film_schema_id"],
        "object_order": order,
        "object_index": {oid: i for i, oid in enumerate(order)},
        "pulsers": [{"id": r, "clock": list(pulsers[r])}
                    for r in sorted(pulsers)],
        "relays": sorted(relays),
        "doors": sorted(doors),
        "spinners": [{"id": s, "w": spinners[s][0], "n": spinners[s][1],
                      "rotor": list(spinners[s][2]),
                      "configurable": bool(conf.get(s, True))}
                     for s in sorted(spinners)],
        "orbs": sorted(orbs),
        "signal_edges": sorted([list(e) for e in sig_edges]),
        "socket_controls": sorted([list(x) for x in sockets]),
    }
    view = _PlanView(plan)
    plan["state_layout_signature"] = _state_layout_signature(view)
    plan["epoch_input_signature"] = _epoch_input_signature(view)
    plan["observable_signature"] = _observable_signature(view)
    return plan


# ------------------------------------------------------ IR -> CompilePlanV1
def artifact_to_compile_plan_v1(artifact):
    """Forge Semantic IR (a SealedArtifact or a raw/reordered artifact dict)
    -> CompilePlanV1. The artifact is canonicalized first, so a reorder-
    equivalent artifact yields a byte-identical plan (3D-1 D2)."""
    if isinstance(artifact, WC.SealedArtifact):
        sem_id = artifact.semantic_id
        art = artifact.artifact
    else:
        sem_id = WC.semantic_artifact_id(artifact)
        art = WC.canonicalize_artifact_v1(artifact)
    pulsers, relays, doors, spinners, orbs, conf = {}, [], [], {}, [], {}
    for o in art["objects"]:
        role, name, cfg = o["role"], o["object_id"], o["static_config"]
        if role == "Pulser":
            pulsers[name] = tuple(cfg["clock"])
        elif role == "Relay":
            relays.append(name)
        elif role == "Door":
            doors.append(name)
        elif role == "Spinner":
            spinners[name] = (cfg["w"], cfg["n"], tuple(cfg["rotor"]))
            conf[name] = bool(cfg.get("configurable"))
        elif role == "Orb":
            orbs.append(name)
    sig_edges = [(e["src"], e["dst"]) for e in art["edges"]
                 if e["kind"] == "SignalWire"]
    sockets = [(e["src"], e["dst"]) for e in art["edges"]
               if e["kind"] == "SocketControl"]
    return _plan_from_parts(sem_id, art["profile_id"],
                            art["semantic_policies"], pulsers, relays, doors,
                            spinners, orbs, sig_edges, sockets, conf)


# ------------------------------------------------- Fixture -> CompilePlanV1
def fixture_to_compile_plan_v1(fx, sem_id, semantic_policies=None,
                               profile_id=None):
    """Fixture (the independent test oracle) -> CompilePlanV1, IDENTICAL to the
    plan the frozen IR produces for the same world (3D-1 D1). The Fixture does
    not itself carry the semantic id or policy bundle, so they are supplied by
    the caller (the sealed artifact's own values), keeping the Fixture a pure
    structural builder."""
    semantic_policies = semantic_policies or {
        "rulepack_id": WC.RULEPACK_ID,
        "numeric_policy_ids": list(WC.NUMERIC_POLICY_IDS),
        "admit_policy_id": WC.ADMIT_POLICY_ID,
        "film_schema_id": WC.FILM_SCHEMA_ID,
    }
    profile_id = profile_id or WC.PROFILE_ID
    pulsers = {r: tuple(spec) for r, spec in fx.pulsers.items()}
    spinners = {s: (w_, n_, tuple(rq))
                for s, (w_, n_, rq) in fx.spinners.items()}
    conf = {s: fx.is_configurable(s) for s in fx.spinners}
    return _plan_from_parts(sem_id, profile_id, semantic_policies, pulsers,
                            list(fx.relays), list(fx.doors), spinners,
                            list(fx.orbs), list(fx.edges), list(fx.sockets),
                            conf)


# --------------------------------------------------------- plan validation
_PLAN_KEYS = ("compile_plan_version", "semantic_artifact_id", "profile_id",
              "rulepack_id", "numeric_policy_ids", "admit_policy_id",
              "film_schema_id", "object_order", "object_index", "pulsers",
              "relays", "doors", "spinners", "orbs", "signal_edges",
              "socket_controls", "state_layout_signature",
              "epoch_input_signature", "observable_signature")


def validate_compile_plan_v1(plan):
    """Structural gate for a CompilePlanV1: version, required keys, and that
    every declared edge/socket endpoint is a declared object. Raises a typed
    WrlValidationError(WRL_BAD_COMPILE_PLAN). Returns the plan on success."""
    if not isinstance(plan, dict):
        WC._fail(WRL_BAD_COMPILE_PLAN, "compile plan must be an object")
    if plan.get("compile_plan_version") != COMPILE_PLAN_VERSION:
        WC._fail(WRL_BAD_COMPILE_PLAN,
                 "unknown compile plan version %r (only %s)"
                 % (plan.get("compile_plan_version"), COMPILE_PLAN_VERSION))
    missing = [k for k in _PLAN_KEYS if k not in plan]
    if missing:
        WC._fail(WRL_BAD_COMPILE_PLAN,
                 "compile plan missing field(s) %s" % missing)
    if not WC._SEM_ID_RE.match(plan["semantic_artifact_id"] or ""):
        WC._fail(WRL_BAD_COMPILE_PLAN,
                 "bad semantic_artifact_id %r" % (plan["semantic_artifact_id"],))
    order = set(plan["object_order"])
    for src, dst in plan["signal_edges"]:
        if src not in order or dst not in order:
            WC._fail(WRL_BAD_COMPILE_PLAN,
                     "signal edge (%s -> %s) references an undeclared object"
                     % (src, dst))
    for s, o in plan["socket_controls"]:
        if s not in order or o not in order:
            WC._fail(WRL_BAD_COMPILE_PLAN,
                     "socket (%s -> %s) references an undeclared object"
                     % (s, o))
    return plan


def compile_plan_digest(plan):
    """TEST-ONLY canonical plan hash. Not a runtime id: it must move iff the
    plan (== the semantic graph) moves, and stay fixed under presentation-only
    edits, so a battery can pin plan/semantic co-movement."""
    validate_compile_plan_v1(plan)
    return "plan-" + WC._sha(WC.serialize_artifact(plan))


# ------------------------------------------- plan -> IC (existing compiler)
def compile_plan_to_ic(plan, lowering_profile):
    """CompilePlanV1 -> (ic_term, fields) via the EXISTING `compile_step_v6`,
    fed through the non-test `_PlanView` shim. The lowering profile is validated
    (it gates the BackendArtifactID) but the IC term itself is the profile-
    neutral reference/native lowering; no new runtime construct is introduced."""
    validate_compile_plan_v1(plan)
    WC.validate_lowering_profile_v1(lowering_profile)
    view = _PlanView(plan)
    step, fields = C.compile_step_v6(view)
    return step, fields


def plan_view(plan):
    """Expose the non-test compiler view of a plan (for state/film helpers that
    take a Fixture-shaped object: init_state_v6, enc_state_v6, dec_state_v6,
    enc_config_bundle, state_to_film_args_v6)."""
    validate_compile_plan_v1(plan)
    return _PlanView(plan)


def compile_artifact(artifact, lowering_profile):
    """Forge Semantic IR (sealed or raw) + lowering profile -> CompiledProgram.
    The production compile path: seal -> CompilePlanV1 -> existing compiler, with
    the BackendArtifactID gated on the SemanticArtifactID AND the lowering
    profile. No Fixture is constructed."""
    plan = artifact_to_compile_plan_v1(artifact)
    step, fields = compile_plan_to_ic(plan, lowering_profile)
    bknd = WC.backend_artifact_id(plan["semantic_artifact_id"], lowering_profile)
    return CompiledProgram(plan, step, fields, bknd)
